﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;
using System;
using System.Net;

namespace APITest
{
    [TestClass]
    public class GovDataAPITest
    {
        private const string _testBaseUrl = @"https://api.data.gov/nrel/alt-fuel-stations/v1/{0}.json?api_key={1}";
        private static string _apiKey = null;

        [TestInitialize]
        public void TestSetup()
        {
            //You may need to obtain apiKey dynamical each time, here just assume it's given
            _apiKey = @"Enph83UpQcQ7kfvo4ZH4EJbmBSS8Jta3ZrlYTWUE";
        }

        #region TestCases
        /// <summary>
        /// This is a test for getting the address for station "Hyatt Austin"
        /// See Spec:https://api.data.gov/docs/nrel/transportation/alt-fuel-stations-v1/
        /// </summary>
        [TestMethod]
        [Owner("Meikang Wu")]
        public void TestNearestAddress()
        {
            UriBuilder nearestUri = new UriBuilder(string.Format(_testBaseUrl,"nearest",_apiKey));
            nearestUri.Query = nearestUri.Query.Substring(1) + "&location=Austin+TX";
            nearestUri.Query = nearestUri.Query.Substring(1) + "&ev_network=ChargePoint+Network"; 
            
            JObject oStations = RequestData(nearestUri.ToString());
            //Find the id of HYATT AUSTIN station
            string id = string.Empty;
            Assert.IsNotNull(oStations["fuel_stations"], "fuel_stations does not exist!");
            JArray stations = (JArray) oStations["fuel_stations"];
            foreach (JObject station in stations)
            {
                if(string.Compare(station["station_name"].ToString(),"HYATT AUSTIN",true)==0)
                {
                    Assert.IsNotNull(station["id"], "id does not exist!");
                    id = station["id"].ToString();
                    break;
                }
            }                       
            Assert.IsFalse(id == string.Empty, "Cannot obtain id from Response");

            //Use the station_id to query the address
            UriBuilder stationUri = new UriBuilder(string.Format(_testBaseUrl, id, _apiKey));
            JObject oStation = RequestData(stationUri.ToString());
            Assert.AreEqual(oStation.First.Path, "alt_fuel_station");
            Assert.IsNotNull(oStation[oStation.First.Path]["street_address"], "street-address does not exist!");             
        }
        #endregion

        #region Helper Method
        public static JObject RequestData(string uri)
        {
            JObject oResult = null;
            using (var client = new WebClient())
            {
                string jsonResult = string.Empty;
                jsonResult = client.DownloadString(uri.ToString());
                Assert.IsFalse(jsonResult==string.Empty, "Response is null");
                try
                {
                    oResult = JObject.Parse(jsonResult);
                }
                catch (Exception e)
                {
                    Assert.Fail("Cannot Parse Response: " + e.ToString());
                }                
            }
            return oResult;
        }

        #endregion
    }
}
