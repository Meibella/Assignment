##Test pre-requisites

1.This tests uses Microsoft.VisualStudio.QualityTools.UnitTestFramework Version=10.1.0.0
2.This test uses Json.Net.Linq library, see https://github.com/JamesNK/Newtonsoft.Json.Schema/blob/master/LICENSE.md for license limit
 

##assumptions 

1.Spec is provided: https://api.data.gov/docs/nrel/transportation/alt-fuel-stations-v1/
1.The test is to validate the API calls can return the street address for a fuel station name "Hyatt Austin" assuming it exists, it does not validate either the address is valid or not.  

##issues found 
N/A