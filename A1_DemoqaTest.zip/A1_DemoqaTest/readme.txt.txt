#Requirements#
1. This test is using Selenium Webdriver version 2.45, it can be downloaded from https://www.nuget.org/packages/Selenium.WebDriver/2.45.0, Refer to http://docs.seleniumhq.org/about/platforms.jsp for supported browser version.


#Build And Run Instruction#
1. Microsoft Visual Studio.Net (Version 11 or above) is required to build the Demoqa.sln solution
2.Vstest.console.exe or Mstest.exe can be used to run the test from console, Too run the test, start a Developer Command Prompt for VS, copy source files along with binaries to the same folder e.g. C:\temp\Demoqa, move to this directory, run the tests using command "Vstest.console.exe DemoqaTest.dll"
3. WebDriver must be copied to the "RelativeDrivepath" that you specified in the App.Config file.

#Issues#
1.IE is not yet tested
2. UpdateAccountAndVerify() is a bit flaky on selecting the logout from list, found similar case: http://stackoverflow.com/questions/28811459/selenium-webdriver-action-not-working-with-primefaces-tieredmenu, but have not had a conclusion so far:(

Please email me if you have any questions,

meikang@gmail.com

  
 


