﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoqaTest
{
    public class BillingInfo
    {
        public string Billingmail {get; set;}
        public string Billingfirstname { get; set; }
        public string Billinglastname { get; set; }
        public string Billingaddress { get; set; }
        public string Billingcity { get; set; }
        public string Billingstate { get; set; }
        public string Billingcountry { get; set; }
        public string Billingphone { get; set; }
        public string Billingpostcode { get; set; }
        public bool isSameBilling { get; set; }       
    }
}
