﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System.Configuration;
using System.IO;

namespace DemoqaTest
{
    #region static class for global settings
    public static class DemoqaTestSettings
    {
        public static int globalTimeoutSec = ConfigurationManager.AppSettings["WaitTimeOutSec"] != null ? int.Parse(ConfigurationManager.AppSettings["WaitTimeOutSec"]) : 60;
        public static int globalPageRefreshTimeoutSec = 1;
        public static string driverPath = Path.Combine(Environment.CurrentDirectory, ConfigurationManager.AppSettings["RelativeDriverPath"]);
        public static string GetFullURL(string pageUrl =null)
        {
            Uri baseUri = new Uri(ConfigurationManager.AppSettings["Domain"]);
            if (pageUrl != null)
            {
                Uri uri = new Uri(baseUri, pageUrl);
                return uri.ToString();
            }
            else
            {
                return baseUri.ToString();
            }
        }
    }
    #endregion   


    #region Helper Class
    public static class DemoqaHelper
    {
        /// <summary>
        /// clear the inpu for insert 
        /// </summary>
        /// <param name="element"></param>
        /// <param name="value"></param>
        public static void InsertValue(this IWebDriver _driver, By elementLocator, string value)
        {
            IWebElement element = _driver.FindElement(elementLocator);
            element.Click();
            element.SendKeys(Keys.Control + "a");
            element.SendKeys(Keys.Delete);
            element.SendKeys(value); 
        }

        /// <summary>
        /// Select values for an element
        /// </summary>
        /// <param name="browser"></param>
        /// <param name="elementID"></param>
        /// <param name="value"></param>
        public static void SelectByValue(this IWebDriver browser, By elementLocator, string value)
        {
            WebDriverWait wait = new WebDriverWait(browser, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
            wait.Until(ExpectedConditions.ElementExists(elementLocator));
            Console.WriteLine("Select by value: " + value);
            SelectElement selector = new SelectElement(browser.FindElement(elementLocator));
            selector.SelectByValue(value);
        }

        /// <summary>
        /// Select text for an element
        /// </summary>
        /// <param name="browser"></param>
        /// <param name="elementID"></param>
        /// <param name="value"></param>
        public static void SelectByText(this IWebDriver browser, By elementLocator, string text)
        {
            WebDriverWait wait = new WebDriverWait(browser, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
            wait.Until(ExpectedConditions.ElementExists(elementLocator));
            Console.WriteLine("Select by text: " + text);
            SelectElement selector = new SelectElement(browser.FindElement(elementLocator));
            selector.SelectByText(text);
        }

        /// <summary>
        /// Checkbox if you want it checked
        /// </summary>
        /// <param name="browser"></param>
        /// <param name="elementLocator"></param>
        /// <param name="yesIwantCheck"></param>
        public static void CheckBox(this IWebDriver browser, By elementLocator, bool yesIwantCheck = false)
        {
            IWebElement checkbox = browser.FindElement(elementLocator);
            if (yesIwantCheck)
            {
                if (!checkbox.Selected)
                    checkbox.Click();
            }
            else
            {
                if (checkbox.Selected)
                    checkbox.Click();
            }                               
        }

        /// <summary>
        /// Scroll down to a position if yAxis is specified or all the way down
        /// </summary>
        /// <param name="browser"></param>
        /// <param name="yAxis"></param>
        public static void ScrollPageDown(IWebDriver browser, int yAxis =-1)
        {
            string jscript = "window.scrollTo(0, Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, document.documentElement.clientHeight));";

            if (yAxis != -1)
                jscript = string.Format("window.scrollTo(0,{0});", yAxis.ToString());
            IJavaScriptExecutor js = (IJavaScriptExecutor) browser;
            js.ExecuteScript(jscript);
        }
    }

    #endregion


    #region Test Class
    [TestClass]
    public class DemoqaTest
    {
        #region Variables
        private IWebDriver _browser;
        private string _defaultPage =ConfigurationManager.AppSettings["Domain"];
      
        /// <summary>
        /// Initalize browser driver based on configuration
        /// </summary>
        [TestInitialize]
        public void InitializeWebDriver()
        {
            string browserType = ConfigurationManager.AppSettings["browser"] != null? ConfigurationManager.AppSettings["Browser"]:"chrome";
            switch(browserType)
            {
                case "chrome": default:
                    ChromeOptions chromeOption = new ChromeOptions();
                    chromeOption.AddArgument("--start-maximized");
                    _browser = new ChromeDriver(ChromeDriverService.CreateDefaultService(DemoqaTestSettings.driverPath), chromeOption, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
					break;
                case "IE":
                    InternetExplorerOptions ieOptions = new InternetExplorerOptions();
					ieOptions.BrowserAttachTimeout = TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec);
                    _browser = new InternetExplorerDriver(InternetExplorerDriverService.CreateDefaultService(DemoqaTestSettings.driverPath), ieOptions, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
                    break;
                case "Firefox":
                    FirefoxProfile ffOptions = new FirefoxProfile();
					_browser = new FirefoxDriver(new FirefoxBinary(), ffOptions, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
                    break;
            }
        }
        #endregion

        #region Setup and Cleanup
        [TestCleanup()]
        public void TestCleanUp()
        {
            if(_browser!=null)
            {
                _browser.Close();
                _browser.Dispose();
            }
        }

        #endregion


        #region Methods
        /// <summary>
        /// Search a product by keyword then click the expected title to add it to cart
        /// </summary>
        /// <param name="productKeyword"></param>
        /// <param name="productTitle"></param>
        public CheckoutPage SearchAddProductToCart(string productKeyword, string productTitle)
        {          
            _browser.Navigate().GoToUrl(DemoqaTestSettings.GetFullURL(""));
            StorePage storePage = new StorePage(_browser);
            storePage.SearchProduct(productKeyword);
            storePage.ClickProductTitle(productTitle);
            ProductDetailPage productDetailPage = storePage.GoToProductDetail(productTitle);
            return productDetailPage.Checkout();
        }
        
        #endregion

        #region Tests

        [TestMethod]
        public void SubmitOrderByProduct()
        {
            decimal productPrice = -1m;
            CheckoutPage checkoutpage = SearchAddProductToCart(@"Apple iPhone 4S 16GB SIM", @"Apple iPhone 4S 16GB SIM-Free – Black");
            checkoutpage = checkoutpage.FinishCheckout();

            //Calculate shipping
            checkoutpage = checkoutpage.CalculateShipping();

            //Fill Billing Info
            //If we need to test variations we can have a method to load it from file           
            BillingInfo info = new BillingInfo();
            info.Billingmail = @"xmen@fake.com";
            info.Billingaddress = @"100 10th St";
            info.Billingcity = @"Bellevue";
            info.Billingcountry = @"USA";
            info.Billingfirstname = @"x";
            info.Billinglastname = @"men";
            info.Billingphone = @"2063334455";
            info.Billingpostcode ="98004";
            info.Billingstate = "WA";
            info.isSameBilling = true;            
            checkoutpage = checkoutpage.FillBillingDetail(info);

            //Check Total Price = product price + shipping
            checkoutpage = checkoutpage.ValidateTotal(out productPrice);

            //Verified the total price in confirmation page
           TransactionResultPage resultPage =  checkoutpage.Purchase();
           resultPage.VerifyFinalPrice(productPrice);
        }

        /// <summary>
        /// Test UpdateAccountAndVerify
        /// Login as default user as specified in the App.Config, change the settings, logout then log back in to verify
        /// </summary>
        [TestMethod]
        public void UpdateAccountAndVerify()
        {
            string testFirstName = "Smart";
            string testLastName = "Beautiful";
            _browser.Navigate().GoToUrl(DemoqaTestSettings.GetFullURL("tools-qa"));

            //Login to profile page
            LoginPage loginPage = new LoginPage(_browser);
            ProfilePage profilePage = loginPage.LoginAs();
            
            //Change some settings the log out
            profilePage.ChangeSettings(testLastName, testFirstName);
            loginPage = profilePage.LogOut();

            //Log back in and verify the change
            profilePage = loginPage.LoginAs();
            profilePage.VerifySettings(testLastName, testFirstName);
        }
               
        /// <summary>
        /// This test only tests the case when the cart is not empty to start with
        /// </summary>
        [TestMethod]
        public void EmptyCart()
        {
            //Add some products
            CheckoutPage checkoutPage;
            checkoutPage = SearchAddProductToCart(@"Apple iPhone 4S 16GB SIM", @"Apple iPhone 4S 16GB SIM-Free – Black");
            checkoutPage = SearchAddProductToCart(@"Apple iPhone 4S 16GB SIM", @"Apple iPhone 4S 16GB SIM-Free – Black");
            checkoutPage = SearchAddProductToCart(@"Asus MX239H 23-inch Widescreen AH", @"Asus MX239H 23-inch Widescreen AH");     

            //We have two different products so expect to click remove twice
            int expectedRemoveOps = 2;
            int actualRemoveOps = 0;

            //Empty cart will throw exception if the message does not show
            checkoutPage.EmptyCart(ref actualRemoveOps);
            Assert.AreEqual(expectedRemoveOps, actualRemoveOps, "Expected: " + expectedRemoveOps + "ACtual:" + actualRemoveOps);
        }
        #endregion

    }
    #endregion
}
