﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoqaTest
{
    public class ProductDetailPage
    {
        #region Variables
        private IWebDriver _driver;
        private By _productContainerLocator = By.Id("single_product_page_container");
        private By _productTitleLocator = By.CssSelector("h1.prodtitle");
        private By _priceLocator = By.CssSelector(" div.wpsc_product_price > p > span");
        private By _addToCartLocator = By.CssSelector(" div.input-button-buy > span > input");
        private By _confirmLocator = By.CssSelector("a.go_to_checkout");

        #endregion

        #region Methods

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="productTitle"></param>
        public ProductDetailPage(IWebDriver driver, string productTitle)
        {
            _driver = driver;
            //Check if product Title is correct
            IWebElement productDetailElement = _driver.FindElement(_productTitleLocator);
            Assert.AreEqual(productDetailElement.Text, productTitle);
        }

        /// <summary>
        /// Add items to cart for checkout
        /// </summary>
        /// <returns></returns>
        public CheckoutPage Checkout()
        {
            List<IWebElement> priceElements = _driver.FindElements(_priceLocator).ToList<IWebElement>();
            bool foundPrice = false;
            string price = "";
            foreach (IWebElement priceELement in priceElements)
            {
                if(priceELement.GetAttribute("class").Contains("currentprice pricedisplay"))
                {
                    //Find the current price
                    price = priceELement.Text;
                    foundPrice = true;
                }
            }

            Assert.IsTrue(foundPrice);
            _driver.FindElement(_addToCartLocator).Click();

            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
            IWebElement confirmElement = wait.Until(ExpectedConditions.ElementIsVisible(_confirmLocator));
            confirmElement.Click();

            return new CheckoutPage(_driver);
        }
        #endregion
    }
}
