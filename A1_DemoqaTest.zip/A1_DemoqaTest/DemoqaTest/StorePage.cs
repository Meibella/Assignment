﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoqaTest
{
    public class StorePage
    {
        #region Variables
        private IWebDriver _driver;
        private By _searchLocator = By.CssSelector("input[value=\"Search Products\"]");

        #endregion

        #region Methods
        public StorePage(IWebDriver driver)
        {
            _driver = driver;
            Assert.IsTrue(string.Compare(_driver.Url, DemoqaTestSettings.GetFullURL(""), true) == 0);
        }

        public StorePage SearchProduct(string productName)
        {
            IWebElement searchElement =_driver.FindElement(_searchLocator);
            searchElement.Click();
            searchElement.SendKeys(Keys.Control + "a");
            searchElement.SendKeys(Keys.Delete);
            searchElement.SendKeys(productName);
            searchElement.SendKeys(Keys.Enter);
            return this;
        }

        public StorePage ClickProductTitle(string productTitle)
        {
            List<IWebElement> linkElements = _driver.FindElements(By.TagName("a")).ToList<IWebElement>();
            bool foundProduct = false;
            foreach(IWebElement linkELement in linkElements)
            {
                if(string.Compare(linkELement.GetAttribute("title"),productTitle, true)==0)
                {
                    linkELement.Click();
                    foundProduct =true;            
                    break;
                }
            }
            Assert.IsTrue(foundProduct);
            return this;
        }
        
        public ProductDetailPage GoToProductDetail(string productTitle)
        {       

            return new ProductDetailPage(_driver, productTitle);

        }
        #endregion
    }
}
