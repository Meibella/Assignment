﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoqaTest
{
    public class TransactionResultPage
    {
        #region Variables
        private IWebDriver _driver;
        private By _finalMessageLocator = By.CssSelector("div.wpsc-transaction-results-wrap > p");

        public TransactionResultPage(IWebDriver driver)
        {
            _driver = driver;
            Assert.AreEqual(_driver.Title, "Transaction Results | ONLINE STORE");
        }
        #endregion

        #region Methods
        /// <summary>
        /// Check the tota price in transaction result page
        /// </summary>
        /// <param name="expectedPrice"></param>
        /// <returns></returns>
        public TransactionResultPage VerifyFinalPrice(decimal expectedPrice)
        {
            string expectedPriceString = string.Format(@"Total: ${0}",expectedPrice.ToString("G"));
            bool isCorrect = false;

            List<IWebElement> messagesElement = _driver.FindElements(_finalMessageLocator).ToList<IWebElement>();
            foreach (IWebElement messageElement in messagesElement)
            {
                if(messageElement.Text.Contains(expectedPriceString))
                {
                    isCorrect = true;
                    break;
                }
            }
            Assert.IsTrue(isCorrect);
            return this;
        }

        #endregion

    }
}
