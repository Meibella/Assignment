﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System.Configuration;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoqaTest
{
    public class ProfilePage
    {
        #region Variables
        private IWebDriver _driver =null;
        private By _profileBarLocator = By.Id("wp-admin-bar-top-secondary");
        private By _profileSubMewuLocator = By.CssSelector("li#wp-admin-bar-my-account > a > div > ul > li");
        private By _logoutLocator = By.Id("wp-admin-bar-logout");
        private By _firstNameLocator = By.Id("first_name");
        private By _lastNameLocator = By.Id("last_name");
        private By _submitLocator = By.Id("submit");

        #endregion

        #region Methods

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="driver"></param>
        public ProfilePage(IWebDriver driver)
        {
            _driver = driver;
            Assert.IsTrue(string.Compare(_driver.Url,DemoqaTestSettings.GetFullURL("wp-admin/profile.php"),true)==0);
        }

        /// <summary>
        /// Hover over the avatar and click logout
        /// </summary>
        /// <returns></returns>
        public LoginPage LogOut()
        {
            DateTime timer = DateTime.Now;
            while(timer.AddSeconds(DemoqaTestSettings.globalTimeoutSec) > DateTime.Now)
            {
                try
                {
                    //Hoover over to the user profile 
                    Actions titlehover = new Actions(_driver);
                    IWebElement profileElement = _driver.FindElement(_profileBarLocator);

                    titlehover.MoveToElement(profileElement).MoveToElement(profileElement.FindElement(_logoutLocator)).Click().Build().Perform();
           
                    ////Wait for the logout option to appear
                    WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
                    wait.Until(ExpectedConditions.ElementIsVisible(_logoutLocator));
        
                    //IWebElement logoutElement = _driver.FindElement(_logoutLocator);
                    ////Click logout
                    //if (logoutElement.Size.Width > 0 && logoutElement.Size.Height > 0)
                    //    logoutElement.Click();
                    break;
                }
                catch
                {
                    _driver.Navigate().Refresh();                   
                }
                           }
            return new LoginPage(_driver);
        }

        /// <summary>
        /// Due to Time constraint, Only allow to change 2 fields for now
        /// </summary>
        /// <param name="lastName"></param>
        /// <param name="firstName"></param>
        /// <returns></returns>
        public ProfilePage ChangeSettings(string lastName, string firstName)
        {
            IWebElement firstNameElement = _driver.FindElement(_firstNameLocator);
            firstNameElement.Click();
            firstNameElement.SendKeys(Keys.Control + "a");
            firstNameElement.SendKeys(Keys.Delete);
            firstNameElement.SendKeys(firstName);

            IWebElement lastNameElement = _driver.FindElement(_lastNameLocator);
            lastNameElement.Click();
            lastNameElement.SendKeys(Keys.Control + "a");
            lastNameElement.SendKeys(Keys.Delete);
            lastNameElement.SendKeys(lastName);

            IWebElement submitElement = _driver.FindElement(_submitLocator);
            submitElement.Submit();
            return this;
        }

        /// <summary>
        /// Due to Time constraint, Only allow to verify 2 fields for now
        /// </summary>
        /// <param name="lastName"></param>
        /// <param name="firstName"></param>
        /// <returns></returns>
        public ProfilePage VerifySettings(string lastName, string firstName)
        {
            IWebElement firstNameElement = _driver.FindElement(_firstNameLocator);
            Assert.AreEqual(firstNameElement.GetAttribute("value").TrimEnd(), firstName);
              
            IWebElement lastNameElement = _driver.FindElement(_lastNameLocator);
            Assert.AreEqual(lastNameElement.GetAttribute("value").TrimEnd(), lastName);

            return this;
        }

        #endregion

    }
}
