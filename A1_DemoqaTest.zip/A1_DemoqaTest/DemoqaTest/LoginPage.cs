﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using System.Web;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemoqaTest
{
    public class LoginPage
    {
        #region Variables
        private IWebDriver _driver;
        private By _usernameLocator = By.Id("user_login");
        private By _passwordLocator = By.Id("user_pass");
        private By _loginSubmit = By.Id("wp-submit");
        #endregion

        #region Methods

        /// <summary>
        /// Page Constructor
        /// </summary>
        /// <param name="driver"></param>
        public LoginPage(IWebDriver driver) 
        {           
            _driver = driver;           
        }
      
        /// <summary>
        /// Type UserName
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public LoginPage TypeUsername(String username=null) 
        {
            username = username == null ? ConfigurationManager.AppSettings["Username"] : username;
            Assert.IsNotNull(username,"UserName not provided!");
            DemoqaHelper.InsertValue(_driver, _usernameLocator, username);          
            return this;
        }

        /// <summary>
        /// Type Password
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public LoginPage TypePassword(String password=null) 
        {
            password = password == null ? ConfigurationManager.AppSettings["Password"] : password;
            Assert.IsNotNull(password, "Password not provided!");
            DemoqaHelper.InsertValue(_driver, _passwordLocator, password);     
            return this;
        }
    
        /// <summary>
        /// Submit login
        /// </summary>
        /// <returns></returns>
        public ProfilePage SubmitLogin()
        {
            _driver.FindElement(_loginSubmit).Submit();
            return new ProfilePage(_driver);
        }
   
        /// <summary>
        /// Submit and expected failure
        /// </summary>
        /// <returns></returns>
        public LoginPage SubmitLoginExpectingFailure() 
        {       
            _driver.FindElement(_loginSubmit).Submit();
            return new LoginPage(_driver);   
        }


        /// <summary>
        /// Allow User to Login
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public ProfilePage LoginAs(String username = null, String password = null)
        {           
            TypeUsername(username);
            TypePassword(password);
            return SubmitLogin();
        }
        #endregion
    }
}
