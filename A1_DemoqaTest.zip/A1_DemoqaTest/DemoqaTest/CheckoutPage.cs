﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace DemoqaTest
{
    public class CheckoutPage
    {
        #region Variables
        private IWebDriver _driver;
        private By _itemRowsLocator = By.CssSelector("table.checkout_cart > tbody > tr > td > form > input[value=\"Remove\"]");
        private By _continueLocator = By.CssSelector("a.step2 > span");
        private By _totalPriceLocator = By.CssSelector("span.yourtotal > span.pricedisplay");
        private By _purchaseLocator = By.CssSelector("div.wpsc_make_purchase > div > div > span > input[value=\"Purchase\"]");
        private By _entryContentLocator = By.CssSelector("div.entry-content");
        
        //Shipping Related Locators
        private By _shippingCalculateLocator = By.CssSelector("input[name=\"wpsc_submit_zipcode\"]");
        private By _shippingTotalLocator = By.CssSelector("table > tbody > tr.total_price.total_shipping");
        private By _shippingCountryLocator = By.Id("current_country");

        //Billing Related Locators
        private By _billingmailLocator = By.CssSelector("input[title =\"billingemail\"]");
        private By _billingfirstnameLocator = By.CssSelector("input[title =\"billingfirstname\"]");
        private By _billinglastnameLocator = By.CssSelector("input[title =\"billinglastname\"]");
        private By _billingaddressLocator = By.CssSelector("textarea[title =\"billingaddress\"]");
        private By _billingcityLocator = By.CssSelector("input[title =\"billingcity\"]");
        private By _billingstateLocator = By.CssSelector("input[title =\"billingstate\"]");
        private By _billingcountryLocator = By.CssSelector("select[title=\"billingcountry\"]");        
        private By _billingphoneLocator = By.CssSelector("input[title =\"billingphone\"]");
        private By _billingpostcodeLocator = By.CssSelector("input[title =\"billingpostcode\"]");
        private By _sameAsBillingLocator = By.Id("shippingSameBilling");

        //Review Total Locators
        private By _shippingValueLocator = By.CssSelector("table > tbody > tr.total_price.total_shipping > td > span > span.pricedisplay");
        private By _itemValueLocator = By.CssSelector("table > tbody > tr.total_price.total_item > td > span > span.pricedisplay");
        private By _taxValueLocator = By.CssSelector("table > tbody > tr.total_price.total_tax > td > span > span.pricedisplay");
        private By _totalValueLocator = By.Id("checkout_total");

        #endregion

        #region Private Methods
        public decimal convertStringToPrice(string price)
        {
            price = price.Trim(new char[] {' ','$'});
            decimal priceAmount;
            Assert.IsTrue(decimal.TryParse(price, out priceAmount));
            return priceAmount;
        }
        #endregion

        #region Public Methods     

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="driver"></param>
        public CheckoutPage(IWebDriver driver)
        {
            _driver = driver;
            Assert.IsTrue(string.Compare(_driver.Url, DemoqaTestSettings.GetFullURL("products-page/checkout/"), true) == 0);
        }

        /// <summary>
        /// validate the total = itemPrice + shipping + tax
        /// </summary>
        /// <returns></returns>
        public CheckoutPage ValidateTotal(out decimal totalPrice)
        {
            decimal shipping = convertStringToPrice(_driver.FindElement(_shippingValueLocator).Text);
            decimal itemPrice = convertStringToPrice(_driver.FindElement(_itemValueLocator).Text);
            decimal tax = convertStringToPrice(_driver.FindElement(_taxValueLocator).Text);
            decimal total = convertStringToPrice(_driver.FindElement(_totalValueLocator).Text);

            Assert.AreEqual(shipping + itemPrice + tax, total);
            totalPrice = total;
            return this;
        }        

        /// <summary>
        /// Keep clicking Remove until cart is empty and check the message
        /// </summary>
        /// <param name="removeTimes"></param>
        /// <returns></returns>
        public CheckoutPage EmptyCart(ref int removeTimes)
        {
            string confirmedMessage = @"Oops, there is nothing in your cart.";
            DateTime started = DateTime.Now;            
            while(!_driver.PageSource.Contains(confirmedMessage) && DateTime.Now.AddSeconds(-2*DemoqaTestSettings.globalTimeoutSec) < started)
            {
                try
                {                  
                    IWebElement firstRow = _driver.FindElement(_itemRowsLocator);                   
                    firstRow.Submit();
                    removeTimes++;
                }
                catch
                {
                    Console.WriteLine("Item Not found!");
                    Thread.Sleep(DemoqaTestSettings.globalPageRefreshTimeoutSec);
                    break;
                }
            }
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
            wait.Until(ExpectedConditions.ElementIsVisible(_entryContentLocator)); 
            Assert.IsTrue(_driver.PageSource.Contains(confirmedMessage));
            return this;
        }

        /// <summary>
        /// Continue to checkout details
        /// </summary>
        /// <returns></returns>
        public CheckoutPage FinishCheckout()
        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));

            IWebElement continueElement = wait.Until(ExpectedConditions.ElementIsVisible(_continueLocator)); 
            if(continueElement.Text =="Continue")
            {
                continueElement.Click();
            }
            else
            {
                Assert.Fail("Failed to continue.");
            }

          
            IWebElement purchaseElement = wait.Until(ExpectedConditions.ElementIsVisible(_purchaseLocator));
            return this;
        }

        /// <summary>
        /// Select country and calculate shipping
        /// </summary>
        /// <returns></returns>
        public CheckoutPage CalculateShipping()
        {

            DemoqaHelper.SelectByText(_driver, _shippingCountryLocator, "USA");

            IWebElement shippingCalculateElement =  _driver.FindElement(_shippingCalculateLocator);
            shippingCalculateElement.Click();
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(DemoqaTestSettings.globalTimeoutSec));
            IWebElement shippingTotalElement = wait.Until(ExpectedConditions.ElementIsVisible(_shippingTotalLocator));
           
            return this;
        }

        /// <summary>
        /// Fill Billing information
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        public CheckoutPage FillBillingDetail(BillingInfo info)
        {
            DemoqaHelper.InsertValue(_driver, _billingmailLocator, info.Billingmail);
            //SCroll to the height of the email for visibility
            DemoqaHelper.ScrollPageDown(_driver, _driver.FindElement(_billingmailLocator).Location.Y);

            DemoqaHelper.InsertValue(_driver,_billingaddressLocator, info.Billingaddress);
            DemoqaHelper.InsertValue(_driver, _billingcityLocator, info.Billingcity);
            DemoqaHelper.SelectByText(_driver, _billingcountryLocator, info.Billingcountry);
            DemoqaHelper.InsertValue(_driver, _billingfirstnameLocator, info.Billingfirstname);
            DemoqaHelper.InsertValue(_driver, _billinglastnameLocator, info.Billinglastname);           
            DemoqaHelper.InsertValue(_driver, _billingphoneLocator, info.Billingphone);
            DemoqaHelper.InsertValue(_driver, _billingpostcodeLocator, info.Billingpostcode);
            DemoqaHelper.InsertValue(_driver,_billingstateLocator, info.Billingstate);
            DemoqaHelper.CheckBox(_driver, _sameAsBillingLocator, info.isSameBilling);    

            return this;
        }

        /// <summary>
        /// Click Purchase
        /// </summary>
        /// <returns></returns>
        public TransactionResultPage Purchase()
        {
            _driver.FindElement(_purchaseLocator).Click();
            return new TransactionResultPage(_driver);
        }
        #endregion
    }
}
